# Human > male and female
class Character:
    def __init__(self, name, health=100, attack=10, score=0, max_health=100, max_attack=10):
        self.name = name
        self.health = health
        self.attack = attack
        self.score = score
        self.max_health = max_health
        self.max_attack = max_attack

