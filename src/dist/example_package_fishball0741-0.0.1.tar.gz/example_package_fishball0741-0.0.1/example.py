from great_text import great_text


# great_text("YOU WON","cyan","chunky")

# great_text("YOU WON","red","coinstak")

# great_text("Game Over","red","colossal")

# great_text("YOU WON","red","letterw3")

great_text("BYEBYE","yellow","smslant")


